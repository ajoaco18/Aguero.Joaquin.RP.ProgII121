package servicio;

import interfaces.CSVFactory;
import interfaces.EventoConFecha;
import modelo.EventoMusical;
import modelo.GeneroMusical;
import java.io.*;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.*;
import java.util.function.Predicate;

public class GestorEventos<T extends EventoConFecha> {
    private List<T> eventos;

    public GestorEventos() {
        this.eventos = new ArrayList<>();
    }

    // Agregar evento
    public void agregar(T evento) {
        eventos.add(evento);
    }

    // Obtener evento por índice
    public T obtener(int indice) {
        return eventos.get(indice);
    }

    // Eliminar evento por índice
    public void eliminar(int indice) {
        eventos.remove(indice);
    }

    // Filtrar eventos por género utilizando Predicate
    public List<T> filtrar(Predicate<T> criterio) {
        List<T> resultado = new ArrayList<>();
        for (T evento : eventos) {
            if (criterio.test(evento)) {
                resultado.add(evento);
            }
        }
        return resultado;
    }

    // Filtrar por género utilizando un Predicate específico
    public List<T> filtrarPorGenero(GeneroMusical genero) {
        return filtrar(evento -> evento instanceof EventoMusical && ((EventoMusical) evento).getGenero() == genero);
    }

    // Filtrar por nombre utilizando un Predicate específico
    public List<T> filtrarPorNombre(String nombre) {
        return filtrar(evento -> evento instanceof EventoMusical && ((EventoMusical) evento).getNombre().contains(nombre));
    }

    public List<T> buscarPorRangoDeFechas(LocalDate inicio, LocalDate fin) {
        Predicate<T> criterioFechas = evento -> evento instanceof EventoMusical && 
                !((EventoMusical) evento).getFecha().isBefore(inicio) && 
                !((EventoMusical) evento).getFecha().isAfter(fin);
        
        return filtrar(criterioFechas);
    }

    // Ordenar eventos por fecha
    public void ordenarPorFecha() {
        eventos.sort(Comparator.comparing(EventoConFecha::getFecha));
    }

    // Ordenar eventos por nombre
    public void ordenarPorNombre() {
        eventos.sort(Comparator.comparing(evento -> ((EventoMusical) evento).getNombre()));
    }

    public void guardarEnCSV(Path ruta) throws IOException {
    // Verificar si el directorio existe
    Path directorio = ruta.getParent();
    if (directorio != null && !Files.exists(directorio)) {
        Files.createDirectories(directorio);  // Crear los directorios si no existen
    }

    // Proceder a guardar el archivo si el directorio es válido
    try (BufferedWriter writer = Files.newBufferedWriter(ruta)) {
        for (T evento : eventos) {
            if (evento instanceof EventoMusical) {
                writer.write(((EventoMusical) evento).toCSV());
                writer.newLine();
            }
        }
    }
}

    public void cargarDesdeCSV(Path ruta, CSVFactory<T> factory) throws IOException {
        try (BufferedReader reader = Files.newBufferedReader(ruta)) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                eventos.add(factory.fromCSV(linea));
            }
        }
    }

    // Guardar eventos en formato binario (cambiado a Path)
    public void guardarEnBinario(Path ruta) throws IOException {
        // Verificar si el directorio existe y crear si no
        if (ruta.getParent() != null && !Files.exists(ruta.getParent())) {
            Files.createDirectories(ruta.getParent());  // Crear los directorios si no existen
        }

        // Guardar los eventos en formato binario
        try (ObjectOutputStream out = new ObjectOutputStream(Files.newOutputStream(ruta))) {
            out.writeObject(eventos);  // Guardamos la lista de eventos
        }
    }

    // Cargar eventos desde un archivo binario (cambiado a Path)
    public void cargarDesdeBinario(Path ruta) throws IOException, ClassNotFoundException {
        if (!Files.exists(ruta)) {
            throw new IOException("El archivo no existe: " + ruta);
        }

        // Leer objetos desde el archivo binario
        try (ObjectInputStream in = new ObjectInputStream(Files.newInputStream(ruta))) {
            // Aquí se hace un cast seguro a List<EventoMusical> si sabes que eventos es de ese tipo
            List<EventoMusical> eventosCargados = (List<EventoMusical>) in.readObject();

            // Solo asignamos si es una lista de EventoMusical
            if (!eventosCargados.isEmpty() && eventosCargados.get(0) instanceof EventoMusical) {
                eventos = (List<T>) eventosCargados;  // Cast a List<T> que es más general
            } else {
                throw new ClassNotFoundException("Tipo de evento no compatible");
            }
        }
    }

    // Método para limpiar la lista de eventos
    public void limpiar() {
        this.eventos.clear();  // Elimina todos los eventos de la lista
    }

    // Mostrar todos los eventos
    public void mostrarTodos() {
        for (T evento : eventos) {
            System.out.println(evento);
        }
    }
}
