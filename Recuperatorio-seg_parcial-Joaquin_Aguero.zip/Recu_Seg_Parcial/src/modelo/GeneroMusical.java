package modelo;

public enum GeneroMusical {
    ROCK, POP, JAZZ, CLASICA, ELECTRONICA
}
