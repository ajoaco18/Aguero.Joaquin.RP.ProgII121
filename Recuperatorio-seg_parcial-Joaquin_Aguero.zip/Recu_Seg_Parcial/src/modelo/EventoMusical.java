package modelo;

import interfaces.EventoConFecha;
import java.io.Serializable;
import java.time.LocalDate;

public class EventoMusical extends Evento implements EventoConFecha, Serializable {
    private static final long serialVersionUID = 1L;

    private String artista;
    private GeneroMusical genero;

    public EventoMusical() {
        super();
    }

    public EventoMusical(int id, String nombre, LocalDate fecha, String artista, GeneroMusical genero) {
        super(id, nombre, fecha);
        this.artista = artista;
        this.genero = genero;
    }

    public String getArtista() {
        return artista;
    }

    public GeneroMusical getGenero() {
        return genero;
    }

    @Override
    public String toString() {
        return "EventoMusical{" +
                "id=" + getId() +
                ", nombre='" + getNombre() + '\'' +
                ", fecha=" + getFecha() +
                ", artista='" + artista + '\'' +
                ", genero=" + genero +
                '}';
    }

    public String toCSV() {
        return getId() + "," + getNombre() + "," + getFecha() + "," + artista + "," + genero;
    }

    public static EventoMusical fromCSV(String csv) {
        String[] datos = csv.split(",");
        if (datos.length != 5) {
            throw new IllegalArgumentException("CSV mal formado: " + csv);
        }
        int id = Integer.parseInt(datos[0]);
        String nombre = datos[1];
        LocalDate fecha = LocalDate.parse(datos[2]);
        String artista = datos[3];
        GeneroMusical genero = GeneroMusical.valueOf(datos[4]);
        return new EventoMusical(id, nombre, fecha, artista, genero);
    }
}
