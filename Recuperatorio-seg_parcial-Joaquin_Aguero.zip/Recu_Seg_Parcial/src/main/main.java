package main;

import java.io.IOException;
import modelo.EventoMusical;
import modelo.GeneroMusical;
import servicio.GestorEventos;
import config.AppConstants; // Importar AppConstants para usar las rutas definidas

import java.time.LocalDate;
import java.util.List;
import java.util.function.Predicate;
import java.nio.file.Path;

public class main {
    public static void main(String[] args) throws IOException, ClassNotFoundException {
        // Crear un gestor de eventos musicales
        GestorEventos<EventoMusical> gestor = new GestorEventos<>();

        // Agregar eventos musicales
        gestor.agregar(new EventoMusical(1, "Rock Fest", LocalDate.of(2024, 3, 15), "Queen Revival", GeneroMusical.ROCK));
        gestor.agregar(new EventoMusical(2, "Jazz Night", LocalDate.of(2024, 6, 20), "John Doe Quintet", GeneroMusical.JAZZ));
        gestor.agregar(new EventoMusical(3, "Pop Party", LocalDate.of(2024, 8, 5), "Taylor Tribute", GeneroMusical.POP));
        gestor.agregar(new EventoMusical(4, "Electronic Vibes", LocalDate.of(2024, 10, 12), "DJ Nova", GeneroMusical.ELECTRONICA));

        // Usar las rutas definidas en AppConstants (ya son Path)
        Path rutaBinario = AppConstants.RUTA_BINARIO;  // Ruta ya es un Path
        Path rutaCSV = AppConstants.RUTA_CSV;          // Ruta ya es un Path

        // Mostrar la lista inicial de eventos
        System.out.println("Lista inicial de eventos:");
        gestor.mostrarTodos();

        // Ordenar por fecha y mostrar
        System.out.println("\nEventos ordenados por fecha:");
        gestor.ordenarPorFecha();
        gestor.mostrarTodos();

        // Ordenar por nombre y mostrar
        System.out.println("\nEventos ordenados por nombre:");
        gestor.ordenarPorNombre();
        gestor.mostrarTodos();

        // Filtrar eventos por género ROCK
        System.out.println("\nEventos de género ROCK:");
        List<EventoMusical> rockEvents = gestor.filtrarPorGenero(GeneroMusical.ROCK);
        for (EventoMusical e : rockEvents) {
            System.out.println(e);
        }

        // Filtrar eventos por nombre que contengan 'Night'
        System.out.println("\nEventos que contienen 'Night' en el nombre:");
        List<EventoMusical> nightEvents = gestor.filtrarPorNombre("Night");
        for (EventoMusical e : nightEvents) {
            System.out.println(e);
        }

        // Filtrar eventos por rango de fechas
        System.out.println("\nEventos entre el 01/01/2024 y el 31/07/2024:");
        List<EventoMusical> dateRangeEvents = gestor.buscarPorRangoDeFechas(LocalDate.of(2024, 1, 1), LocalDate.of(2024, 7, 31));
        for (EventoMusical e : dateRangeEvents) {
            System.out.println(e);
        }

        // Guardar y cargar en formato binario
        System.out.println("\nGuardando y cargando eventos en binario...");
        gestor.guardarEnBinario(rutaBinario); 
        gestor.limpiar(); 
        gestor.cargarDesdeBinario(rutaBinario);
        gestor.mostrarTodos();

        // Guardar y cargar eventos en CSV
        System.out.println("\nGuardando y cargando eventos en CSV...");
        try {
            gestor.guardarEnCSV(rutaCSV); 
            gestor.mostrarTodos();
        } catch (Exception ex) {
            System.out.println("Error al guardar/cargar en CSV: " + ex.getMessage());
        }

        // Filtrar eventos dinámicamente usando un Predicate
        System.out.println("\nFiltrar eventos dinámicamente (artista contiene 'DJ'): ");
        Predicate<EventoMusical> filtroArtista = e -> e.getArtista().contains("DJ");
        List<EventoMusical> filtroDinamico = gestor.filtrar(filtroArtista);
        for (EventoMusical e : filtroDinamico) {
            System.out.println(e);
        }
    }
}
