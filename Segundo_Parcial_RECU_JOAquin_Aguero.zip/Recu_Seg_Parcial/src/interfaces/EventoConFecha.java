package interfaces;

import java.time.LocalDate;

public interface EventoConFecha {
    LocalDate getFecha();
}
