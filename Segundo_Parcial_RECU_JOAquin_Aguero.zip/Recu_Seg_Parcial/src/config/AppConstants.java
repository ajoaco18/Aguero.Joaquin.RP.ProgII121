package config;

import java.nio.file.Path;
import java.nio.file.Paths;

// Rutas de archivo como Path
public class AppConstants {
    
    public static final Path RUTA_BINARIO = Paths.get("eventos.dat");
    public static final Path RUTA_CSV = Paths.get("eventos.csv");
}
